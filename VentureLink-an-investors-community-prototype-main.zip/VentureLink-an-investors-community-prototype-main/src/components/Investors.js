function Investors() {
    return ( 
        <div>
            temp
        </div>
     );
}

export default Investors;